<?php
require_once __DIR__ . '/Facebook/autoload.php';
/**
 *  
 *
 *  
 *
 */
 
/**
 * Class Fblib
 *
 * @package Fblib
 */
class Fblib
{
    /**
     * @const string Version number of the Facebook PHP SDK.
     */
    const VERSION = '1.0.0';

    /**
     * @login url
     */
    protected $login_url = '';
    /**
     * @login url
     */
    protected $logout_url = '';
    /**
     * @facebookuser_id
     */
    protected $facebookuser_id = '';
    /**
     * @picPath url
     */
    protected $picPath = '';
    /**
     * @scope for permissions
     */
    protected $scope = '';
    /**
     * @user_profile
     */
    protected $user_profile = array();

    /**
     * @appId
     */
    protected $appId = '';
 
     /**
     * @secret
     */
    protected $secret = '';
    
     /**
     * @fbobject
     */
    protected $fbobject ;
    
    /**
     * @fbobject
     */
    protected $helper ;
 
    /**
     * Instantiates a new Facebook super-class object.
     *
     * @param array $config
     *
     * @throws FacebookSDKException
     */
    public function __construct(array $config = [])
    { 
		  
		 if (isset($config['secret']) && isset($config['appId']) ) {
		  $fb = new \Facebook\Facebook([
				  'app_id' => $config['appId'],
				  'app_secret' => $config['secret'],
				  'default_graph_version' => 'v2.5',
				]);
		  
		 $this->debugx($this->login_url );
		 $this->debug($_SESSION);
		  
		  
		 $this->fbobject = $fb;		
		}
		
		 
		//$this->debug($this->fbobject);
		//echo 'zzzzzz';		
    }

		
		 
    /**
     * Returns the FacebookApp entity.
     *@param array $data_scop
     * @return FacebookApp
     */
    public function getFacebookLogin($data_scop = array())
    {
		$data = array();
		
		 $this->helper = $this->fbobject->getRedirectLoginHelper();
		
		 
		 $permissions = ['email', 'user_likes']; // optional
		 $this->login_url = $this->helper->getLoginUrl('http://facebookapi.com/?fbrespons=1', $permissions);
		 
		 $data['user_profile'] = '';
		$data['facebookuser_id'] = '';
		$data['picPath'] = '';
		$data['login_url'] = $this->login_url;
		$data['logouturl'] = '';
		$data['state'] = $_SESSION['FBRLH_state'];
		
        return $data;
    }
    
    /**
     * Returns the FacebookApp entity.
     *
     * @return FacebookApp
     */
    public function getToken()
    {
		
		try {
			  $accessToken = $this->helper->getAccessToken();
			} catch(Facebook\Exceptions\FacebookResponseException $e) {
			  // When Graph returns an error
			  echo 'Graph returned an error: ' . $e->getMessage();
			  exit;
			} catch(Facebook\Exceptions\FacebookSDKException $e) {
			  // When validation fails or other local issues
			  echo 'Facebook SDK returned an error: ' . $e->getMessage();
			  exit;
			}
				
				$this->debugx($accessToken  ); 
        return 'working';
    }
    
    /**
     * Returns the FacebookApp entity.
     *
     * @return FacebookApp
     */
    public function getUser()
    {
		 
        try {
			  $response =  $this->fbobject->get('/me');
			} catch(Facebook\Exceptions\FacebookSDKException $e) {
			  // . . .
			  $this->debugx( 'Facebook SDK returned an error: ' . $e->getMessage());
			  exit;
			}

			$plainOldArray = $response->getDecodedBody();

		  //
		  $this->debug($plainOldArray  );
    }
    
    
	public	function debug($arr){
			echo '<pre>';
			print_r($arr);
			echo '</pre>';
		}
	public	function debugx($v){
			$a = '<br>|'.str_repeat("*", 57).'|<br>';
			echo $a;
			echo $v;
			echo $a;
		}


    
}
 
