<?php
  require_once __DIR__ . '/fbold/functions.php';
  require_once __DIR__ . '/fbold/Facebook.php';
 
	$facebook = new Facebook_Facebook(array('appId' => APPID, 'secret' => SECRET));
	$facebookuser_id = $facebook->getUser();
    
    if ($facebookuser_id) {
		
            try {
                $user_profile = $facebook->api($facebookuser_id);
                //$array = get_headers('https://graph.facebook.com/'.$facebookuser_id.'/picture?type=large', 1);
                $picPath = get_headers('https://graph.facebook.com/' . $facebookuser_id . '/picture', 1);


                $_SESSION['facebook-name'] = $user_profile['first_name'] . " " . $user_profile['first_name'] . " (Facebook)";
                $_SESSION['facebooklogouturl'] = $facebook->getLogoutUrl(array('next' => 'http://facebookapi.com/logout.php?facebookresponse=2'));
                $_SESSION['facebook_picpath'] = $picPath['Location'];
                $_SESSION['facebookloggedin'] = 1;
            } catch (FacebookApiException $e) {
                $login_url = $facebook->getLoginUrl(array(
                    'scope' => 'email,user_posts,publish_actions,manage_pages,publish_pages',
                    'redirect_uri' => 'http://facebookapi.com/login-callback.php?facebookresponse=1'
                ));
                $_SESSION['facebookloginurl'] = $login_url;
                
            }
            echo '<a href="' .  $_SESSION['facebooklogouturl'] . '">Logout from Facebook!</a>';
        } else {
            $login_url = $facebook->getLoginUrl(array(
                'scope' => 'email,user_posts,publish_actions,manage_pages,publish_pages',
                'redirect_uri' => 'http://facebookapi.com/login-callback.php?facebookresponse=1'
            ));
            $_SESSION['facebookloginurl'] = $login_url;
            echo '<a href="' . $login_url . '">Log in with Facebook!</a>';
        }
        

debug($_SESSION);
 //header('location: http://facebookapi.com/login-callback.php?facebookresponse=1');
