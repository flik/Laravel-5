<?php
session_start() ;
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

const APPID = '1513209702228507'; //'1242577869137517'; //New RecruitBPM
const SECRET = '044ff015e9587d2f270a240cf6370de0'; //'62bcbd6ce644cf438a8ee0c2e6b75099'; //New RecruitBPM

 function debug($arr){
			echo '<pre>';
			print_r($arr);
			echo '</pre>';
		}
 function debugx($v){
			$a = '<br>|'.str_repeat("*", 57).'|<br>';
			echo $a;
			echo $v;
			echo $a;
		}

?>
