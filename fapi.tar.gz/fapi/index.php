<?php
  require_once __DIR__ . '/fbold/functions.php';
//  require_once __DIR__ . '/fbold/Facebook.php';
 require_once __DIR__ . '/Facebook/autoload.php';
  
	$fb = new Facebook\Facebook([
  'app_id' => APPID,
  'app_secret' => SECRET,
  'default_graph_version' => 'v2.8',
  'default_access_token' => isset($_SESSION['facebook_access_token']) ? $_SESSION['facebook_access_token'] : APPID.'|'.SECRET
]);

$helper = $fb->getRedirectLoginHelper();
	try {
	  $response = $fb->get('/me?fields=id,name');
	  $user = $response->getGraphUser();
	  $facebookuser_id = $user['id'];
	  $token = $_SESSION['facebook_access_token'];
	  $picPath = get_headers('https://graph.facebook.com/' . $user['id'] . '/picture', 1);
	  
	  echo '<img src="'.$picPath['Location'].'" id="imLogo" name="imLogo"  border="0"><br>Name: ' . $user['name'];
	    
	     	
		//for  posting on wall
		$data = array('message' => 'Test message disregard it.',
							'name' => 'Job Title', 
							'caption' => 'Job Caption', 
							'link' => 'http://www.recruitbpm.com/', 
							'description' => 'Test My Description ', 
							'actions' => json_encode(array('name' => 'Get Search', 'link' => 'http://www.recruitbpm.com/')));
										
		//$res = $fb->api("/$facebookuser_id/feed/", 'post', $data);
		# POST request in v5
		//$res = $fb->post('/me/feed', $data, $_SESSION['facebook_access_token']);
		
		 // To get Page Liset with Old SDK
		$graph_url_pages = "https://graph.facebook.com/me/accounts?access_token=" . $token;
		$pages = array();
		//$pages = json_decode(file_get_contents($graph_url_pages)); // get all pages information from above url.
		$dropdown = "";
		//Publishing on pages
		for ($i = 0; $i < count($pages->data); $i++) {
			//$dropdown .= "<option value='" . $pages->data[$i]->access_token . "-" . $pages->data[$i]->id . "'>" . $pages->data[$i]->name . "</option>";
			$page_token = $pages->data[$i]->access_token;
			$page_id = $pages->data[$i]->id;
			$publish = $fb->post('/' . $page_id . '/feed', array('access_token' => $page_token,
								  'message' => 'Testing',
									'from' => APPID,
									'to' => $page_id,
									'caption' => 'Testing title disregard it!',
									'name' => 'Testing name disregard it!',
									'link' => 'http://testvirtelligence.recruitbpm.com/cportal/index/detail/id/15979' ,
									'picture' => 'http://www.planwallpaper.com/static/images/desktop-year-of-the-tiger-images-wallpaper.jpg',
									'description' => 'Here is test description...'
									), $page_token);
		
		}
		
		//debug($publish);
		
		$logoutUrl = 'https://www.facebook.com/logout.php?next=' . 'http://facebookapi.com/logout.php?facebookresponse=2' .  '&access_token='.$_SESSION['facebook_access_token'];
 
	echo '<hr><a href="' . $logoutUrl . '">Log out from Facebook!</a>';

	  //redirect, or do whatever you want
	} catch(Facebook\Exceptions\FacebookResponseException $e) {
	  debugx( 'Graph returned an error: ' . $e->getMessage());
	} catch(Facebook\Exceptions\FacebookSDKException $e) {
	  debugx( 'Facebook SDK returned an error: ' . $e->getMessage());
	}
	
	$permissions = ['email', 'user_likes'];
	$loginUrl =$helper->getLoginUrl('http://facebookapi.com/login-callback.php?facebookresponse=1', $permissions);

    if(!isset($_SESSION['facebook_access_token']))           
	echo '<hr><a href="' . $loginUrl . '">Log in with Facebook!</a>';
		
	
	/*
	  
	 
	//Getting a Long-Lived (Extended) Access Token in v5
	$accessToken = $helper->getAccessToken();
	$oAuth2Client = $fb->getOAuth2Client();
	$longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
	$_SESSION['facebook_access_token'] = (string) $longLivedAccessToken;
	
	
	# GET request in v5
	$fb->setDefaultAccessToken('{access-token}');

	# These will fall back to the default access token
	$res = $fb->get('/me');
	$res = $fb->post('/me/feed', $data);
	$res = $fb->delete('/123', $data);
	 
	 
	 
	# v5 response example
	$res = $fb->get('/me');

	$node = $res->getGraphObject();

	var_dump($node->getProperty('id'));
	// string(3) "123"

	// Functional-style!
	$node->map(function($value, $key) {
	  // . . .
	});
	 
	 // v5 file upload
	 $data = [
	  'source' => $fb->fileToUpload('/path/to/photo.jpg'),
	  'message' => 'My file!',
	  ];

	$response = $fb->post('/me/photos', $data, '{access-token}');
 
	// v5 video upload
	 $data = [
	  'source' => $fb->videoToUpload('/path/to/video.mp4'),
	  'title' => 'My video',
	  'description' => 'My amazing video!',
	  ];

	$response = $fb->post('/me/videos', $data, '{access-token}');
	 
	 
	// v5 User Logout
	 
	$helper = $fb->getRedirectLoginHelper();

	$logoutUrl = $helper->getLogoutUrl('{access-token}', 'http://example.com');
	echo '<a href="' . $logoutUrl . '">Logout of Facebook!</a>';
	 
	 
 
* 
  
* 
* 
* 
* 
* 
* 
* 
	$facebookuser_id = $facebook->getUser();
    
    if ($facebookuser_id) {
		
            try {
                $user_profile = $facebook->api($facebookuser_id);
                //$array = get_headers('https://graph.facebook.com/'.$facebookuser_id.'/picture?type=large', 1);
                $picPath = get_headers('https://graph.facebook.com/' . $facebookuser_id . '/picture', 1);

				$_SESSION['profile-name'] = $user_profile;
                $_SESSION['facebook-name'] = $user_profile['name'] . " (Facebook)";
                $_SESSION['facebooklogouturl'] = $facebook->getLogoutUrl(array('next' => 'http://facebookapi.com/logout.php?facebookresponse=2'));
                $_SESSION['facebook_picpath'] = $picPath['Location'];
                $_SESSION['facebookloggedin'] = 1;
            } catch (FacebookApiException $e) {
                $login_url = $facebook->getLoginUrl(array(
                    'scope' => 'email,user_posts,publish_actions,manage_pages,publish_pages',
                    'redirect_uri' => 'http://facebookapi.com/login-callback.php?facebookresponse=1'
                ));
                $_SESSION['facebookloginurl'] = $login_url;
                
            }
            echo '<a href="' .  $_SESSION['facebooklogouturl'] . '">Logout from Facebook!</a>';
        } else {
            $login_url = $facebook->getLoginUrl(array(
                'scope' => 'email,user_posts,publish_actions,manage_pages,publish_pages',
                'redirect_uri' => 'http://facebookapi.com/login-callback.php?facebookresponse=1'
            ));
            $_SESSION['facebookloginurl'] = $login_url;
            echo '<a href="' . $login_url . '">Log in with Facebook!</a>';
        }
        
*/
debug($_SESSION);
 //header('location: http://facebookapi.com/login-callback.php?facebookresponse=1');
