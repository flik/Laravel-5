<?php
require_once __DIR__ . '/fbold/functions.php';
require_once __DIR__ . '/fbold/Facebook.php';

$facebook = new Facebook_Facebook(array('appId' => APPID, 'secret' => SECRET));
        $facebook->destroySession();
        unset($_SESSION['isFbConfig']);
        unset($_SESSION['name']);
        unset($_SESSION['picture_url']);

        unset($_SESSION['facebook-name']);

        unset($_SESSION['facebook_picpath']);
        unset($_SESSION['facebookloggedin']);
        $logout_url = $_SESSION['facebooklogouturl'];
        unset($_SESSION['facebooklogouturl']);
//        unset($_SESSION['fblo)gout']);
//        header('location: ' . $this->_appurl . '/index/?facebookresponse=2');
//        header('location: ' . $_SESSION['social_back_url']);
 
header('location: http://facebookapi.com/index.php?facebookresponse=2');
             
