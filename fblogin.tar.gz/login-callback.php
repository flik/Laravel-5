<?php
  require_once __DIR__ . '/fbold/functions.php';
//require_once __DIR__ . '/Facebook/autoload.php';
  require_once __DIR__ . '/fbold/Facebook.php';
 
$facebook = new Facebook_Facebook(array('appId' => '1513209702228507', 'secret' => '044ff015e9587d2f270a240cf6370de0'));
	$facebookuser_id = $facebook->getUser();
  
 
        
	if ($facebookuser_id) {
                try {
                    $user_profile = $facebook->api($facebookuser_id);
                    //$array = get_headers('https://graph.facebook.com/'.$facebookuser_id.'/picture?type=large', 1);
                    $picPath = get_headers('https://graph.facebook.com/' . $facebookuser_id . '/picture', 1);


                    $_SESSION['facebook-name'] = $user_profile['first_name'] . " " . $user_profile['first_name'] . " (Facebook)";
                    $_SESSION['facebooklogouturl'] = $facebook->getLogoutUrl(array('next' => 'http://facebookapi.com/index.php?facebookresponse=2'));
                    $_SESSION['facebook_picpath'] = $picPath['Location'];
                    $_SESSION['facebookloggedin'] = 1;
 
                    unset($_SESSION['facebookloginurl']);
                    //header('location: http://facebookapi.com/login-callback.php?facebookresponse=1');
                } catch (FacebookApiException $e) {
                    $login_url = $facebook->getLoginUrl(array(
                        'scope' => 'email,user_posts,publish_actions,manage_pages,publish_pages',
                        'redirect_uri' => 'http://facebookapi.com/login-callback.php?facebookresponse=1'
                    ));

                    $_SESSION['facebookloginurl'] = $login_url;
                    //header('location: http://facebookapi.com/login-callback.php?facebookresponse=1');
                }
            } else {
                $login_url = $facebook->getLoginUrl(array(
                    'scope' => 'email,user_posts,publish_actions,manage_pages,publish_pages',
                    'redirect_uri' => 'http://facebookapi.com/login-callback.php?facebookresponse=1'
                ));

                $_SESSION['facebookloginurl'] = $login_url;
                //header('location: http://facebookapi.com/login-callback.php?facebookresponse=1');
            }
            
            debug($_SESSION);
            
            echo '<a href="' . $_SESSION['facebooklogouturl'] . '">Logout in with Facebook!</a>';
