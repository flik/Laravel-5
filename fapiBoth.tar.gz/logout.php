<?php
  require_once __DIR__ . '/fbold/functions.php';
//  require_once __DIR__ . '/fbold/Facebook.php';
 require_once __DIR__ . '/Facebook/autoload.php';
  
	$fb = new Facebook\Facebook([
  'app_id' => APPID,
  'app_secret' => SECRET,
  'default_graph_version' => 'v2.8',
  'default_access_token' => isset($_SESSION['facebook_access_token']) ? $_SESSION['facebook_access_token'] : APPID.'|'.SECRET
]);
session_destroy();
/*
        unset($_SESSION['isFbConfig']);
        unset($_SESSION['name']);
        unset($_SESSION['picture_url']);

        unset($_SESSION['facebook-name']);

        unset($_SESSION['facebook_picpath']);
        unset($_SESSION['facebookloggedin']);
        $logout_url = $_SESSION['facebooklogouturl'];
        unset($_SESSION['facebooklogouturl']);
//        unset($_SESSION['fblo)gout']);
//        header('location: ' . $this->_appurl . '/index/?facebookresponse=2');
//        header('location: ' . $_SESSION['social_back_url']);
 */
 
header('location: http://facebookapi.com/index.php?facebookresponse=2');
             
